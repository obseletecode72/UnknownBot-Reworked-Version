import { Bot } from 'mineflayer';
export declare function plugin(bot: Bot): void;
export { CollectBlock, Callback, CollectOptions } from './CollectBlock';
