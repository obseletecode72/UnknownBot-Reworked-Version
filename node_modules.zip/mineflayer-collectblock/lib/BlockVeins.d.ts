import { Bot } from 'mineflayer';
import { Block } from 'prismarine-block';
export declare function findFromVein(bot: Bot, block: Block, maxBlocks: number, maxDistance: number, floodRadius: number): Block[];
