module.exports = (bot, { version }) => {
  bot.once('spawn', () => console.log('hello world!'))
}
